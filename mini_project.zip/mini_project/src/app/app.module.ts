import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LayoutModule } from './layout/layout.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HomeComponent } from './home/home.component';
import { SaleComponent } from './sale/sale.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import {HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import { SortHighToLowPipe } from './pipes/sort-high-to-low.pipe';
import { SortlowToHighPipe } from './pipes/sortlow-to-high.pipe';
import { NameaZPipe } from './pipes/namea-z.pipe';
import { NamezAPipe } from './pipes/namez-a.pipe';
import { CartComponent } from './cart/cart.component';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { CommonInterceptor } from './common.interceptor';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    SaleComponent,
    SidenavComponent,
    SortHighToLowPipe,
    SortlowToHighPipe,
    NameaZPipe,
    NamezAPipe,
    CartComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    LayoutModule,
    BrowserAnimationsModule,
    MatSnackBarModule
  ],
  providers: [
    {provide:HTTP_INTERCEPTORS,useClass:CommonInterceptor,multi:true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
