import { SalesService } from './../sales.service';
import { Component, OnInit } from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import { ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { McartService } from '../mcart.service';
import {MatSnackBar} from '@angular/material/snack-bar';

@Component({
  selector: 'app-sale',
  templateUrl: './sale.component.html',
  styleUrls: ['./sale.component.css']
})
export class SaleComponent implements OnInit {
  products:any;
  cartitems:any;
  cartlength:any;
  products1:any;
  constructor(private salesService:SalesService,private mcartService:McartService,private _snackBar: MatSnackBar) { }
  title="Sale";
  setpipe="nameaZ";
  isOpen=false;
  gridview=true;
  listview=false;
  tableview=false;
  displayedColumns: string[] = ['id','name','offer','price','action','cart'];
  @ViewChild(MatPaginator) paginator!:MatPaginator;
  ngOnInit(): void {
    this.salesService.getusers().subscribe(data => {
      this.products=data;
      this.products1=new MatTableDataSource(<any> data);
      this.products1.paginator = this.paginator;
      //console.log(typeof data);
      //console.log(Object.keys(data).length)
    });
  }

  openSnackBar() {
    this._snackBar.open('Item Added Sucessfully', 'x', {
      horizontalPosition: 'center',
      verticalPosition:'top',
    });
  }

  addtocart(i:any)
  {
    this.mcartService.getproducts().subscribe(data => {
      this.cartitems=data;
      this.cartlength=Object.keys(data).length;
    });
    let idexist=false
    if(this.cartlength>0)
    {
    for(let x of this.cartitems)
    {
      if(x.id == i.id)
      {
        idexist=true;
        break;
      }
    }
  }
    if(idexist)
    {
      //console.log("updated");
      i.count += 1;
      this.mcartService.updateproduct(i).subscribe();
      this.openSnackBar();
    }
    else
    {
      i.count=1;
      this.mcartService.addproduct(i).subscribe();
      this.openSnackBar();
    }
  }

}
