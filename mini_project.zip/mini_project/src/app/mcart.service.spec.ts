import { TestBed } from '@angular/core/testing';

import { McartService } from './mcart.service';

describe('McartService', () => {
  let service: McartService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(McartService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
