import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { createComponentType } from '@angular/compiler/src/render3/view/compiler';
import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { McartService } from '../mcart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit{

  constructor(private mcartService:McartService,private fb:FormBuilder) { }
  itemsincart:any;
  cartempty!: number;
  noOfitemsInCart:number=0;
  noOfItems!:FormGroup;
  Sub_total:number=0;
  shipping_cost:number=0;
  grand_total1:number=0;
  ngOnInit(): void {
    
    this.mcartService.getproducts().subscribe(data =>{
      this.itemsincart=data;
      this.cartempty=Object.keys(data).length;
      this.calculate_subtotal();
      this.calculate_shipping();
      this.grand_total();
    });
  }

  deleteitem(id:any)
  {
    this.mcartService.deleteproduct(id).subscribe();
    this.mcartService.getproducts().subscribe(data =>{
      this.itemsincart=data;
      this.cartempty=Object.keys(data).length;
      this.calculate_subtotal();
      this.calculate_shipping();
      this.grand_total();
    });
  }

  displayvalue(i:any)
  {
    this.noOfItems.setValue({
      items:this.itemsincart[i].count
    });
    //console.log(this.itemsincart[i].count);
  }
  
  deleteAllItems()
  {
    for(let item of this.itemsincart)
    {
      this.mcartService.deleteproduct(item.id).subscribe();
    }
    this.mcartService.getproducts().subscribe(data =>{
      this.itemsincart=data;
      this.cartempty=Object.keys(data).length;
      this.Sub_total=0;
      this.shipping_cost=0;
      this.grand_total1=0;
    });
  }

  reduceCount(body:any)
  {
    if(body.count>0)
    {
    body.count--;
    this.mcartService.updateproduct(body).subscribe();
    this.calculate_subtotal();
      this.calculate_shipping();
      this.grand_total();
    }
  }

  increaseCount(body:any)
  {
    body.count++;
    this.mcartService.updateproduct(body).subscribe();
    this.calculate_subtotal();
      this.calculate_shipping();
      this.grand_total();
  }
  //caluclate subtotal
  calculate_subtotal()
  {
    let sub=0;
    let cn=0;
    for(let x of this.itemsincart)
    {
      let p=x.price;
      let c=x.count;
      cn += c;
      let z=p*c;
      sub += z;
    }
    this.Sub_total=sub;
    this.noOfitemsInCart=cn;
  }
  //caluclate shippingcost
  calculate_shipping()
  {
    let ship=0;
    for(let x of this.itemsincart)
    {
      let c=x.count;
      let z=1*c;
      ship +=z;
    }
    this.shipping_cost=ship;
  }
  //grandtotal
  grand_total()
  {
    this.grand_total1=this.Sub_total+this.shipping_cost
  }
  
}
