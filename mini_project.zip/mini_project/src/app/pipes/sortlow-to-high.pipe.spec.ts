import { SortlowToHighPipe } from './sortlow-to-high.pipe';

describe('SortlowToHighPipe', () => {
  it('create an instance', () => {
    const pipe = new SortlowToHighPipe();
    expect(pipe).toBeTruthy();
  });
});
