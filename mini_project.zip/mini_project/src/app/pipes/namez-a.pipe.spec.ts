import { NamezAPipe } from './namez-a.pipe';

describe('NamezAPipe', () => {
  it('create an instance', () => {
    const pipe = new NamezAPipe();
    expect(pipe).toBeTruthy();
  });
});
