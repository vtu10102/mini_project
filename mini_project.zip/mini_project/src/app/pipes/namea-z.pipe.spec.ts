import { NameaZPipe } from './namea-z.pipe';

describe('NameaZPipe', () => {
  it('create an instance', () => {
    const pipe = new NameaZPipe();
    expect(pipe).toBeTruthy();
  });
});
