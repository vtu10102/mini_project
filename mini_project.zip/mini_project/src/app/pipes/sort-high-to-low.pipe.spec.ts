import { SortHighToLowPipe } from './sort-high-to-low.pipe';

describe('SortHighToLowPipe', () => {
  it('create an instance', () => {
    const pipe = new SortHighToLowPipe();
    expect(pipe).toBeTruthy();
  });
});
