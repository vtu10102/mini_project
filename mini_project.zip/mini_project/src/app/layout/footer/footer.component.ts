import { Component, OnInit } from '@angular/core';
import { FormControl, Validators ,FormGroupDirective, NgForm, FormGroup, FormBuilder} from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material/core';

/** Error when invalid control is dirty, touched, or submitted. */
export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})

export class FooterComponent implements OnInit {
  Categoriesview=false;
  offersview=false;
  Infoview=false;
  Servicesview=false;
  constructor(private fb:FormBuilder) { }
  emailform!: FormGroup;
  ngOnInit(): void {
    this.emailform = this.fb.group({
      'email' : new FormControl('', [
        Validators.email
      ])
    });
    
  }
   

  matcher = new MyErrorStateMatcher();

}
