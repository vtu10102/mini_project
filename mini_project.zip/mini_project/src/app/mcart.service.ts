import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class McartService {

  constructor(private http:HttpClient) { 
  }

  getproducts()
  {
    return this.http.get("http://localhost:3000/cart");
  }
  addproduct(body:object)
  {
    return this.http.post('http://localhost:3000/cart',body);
  }
  updateproduct(i:any)
  {
    let url="http://localhost:3000/cart/"+i.id;
    return this.http.put(url,i);
  }
  deleteproduct(id:any)
  {
    let url="http://localhost:3000/cart/"+id;
    return this.http.delete(url);

  }
}
